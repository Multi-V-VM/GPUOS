Main document: main.tex
Build: latexmk -pdf -jobname=GPUOS-arXiv main.tex
12 body pages plus 1 reference page.
The architecture distinguishes implemented prototypes from proposed services.
Author remains Working draft; fill in the actual authors before submission.
